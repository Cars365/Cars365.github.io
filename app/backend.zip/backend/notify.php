<?php

  //header('Content-Type: application/json');
  require 'phpmailer/PHPMailerAutoload.php';

  function sendNotificationMail($data)
  {
      $message = "Hi,";
      $message .= "<br /><br />";
      $message .= "Received a new query from landing page,";
      $message .= "<br />Brand :". $data['brand'];
      $message .= "<br />Model :". $data['model'];
      $message .= "<br />Year :". $data['year'];
      $message .= "<br />Variant :". $data['variant'];
      $message .= "<br />Phone Number :". $data['phone'];

      $mail             = new PHPMailer();
      $body             = $message;
      //$body             = preg_replace("[\]",'',$body);
      $mail->IsSMTP(); // telling the class to use SMTP
      $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
      $mail->SMTPAuth   = true;                  // enable SMTP authentication
      $mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
      $mail->Host       = "ssl://smtp.gmail.com";      // sets GMAIL as the SMTP server
      $mail->Port       = 465;                   // set the SMTP port for the GMAIL server
      $mail->Username   = "careers.elpisdesign@gmail.com";  // GMAIL username
      $mail->Password   = "asdf@1234";            // GMAIL password

      $mail->SetFrom('careers.elpisdesign@gmail.com', 'ElpisDeign Careers');
      //$mail->AddReplyTo("suyash@codevigor.com","MyVillasMauritius");
      $mail->AddCC('aman@elpisdesign.com');
      $mail->AddBCC('aseem@elpisdesign.com');
      $mail->Subject    = "New query from landing page.";
      $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

      $mail->MsgHTML($body);

      $address = "aman@cars365.in";
      // $address = "ipians.aman@gmail.com";
      $mail->AddAddress($address, "");


      if(!$mail->Send()) {
        echo json_encode(array("success" => 0, "message" => "Failed!"));
      } else {
        echo json_encode(array("success" => 1, "message" => "Sent Successfully!"));
      }
  }

  sendNotificationMail($_GET);
  ?>
